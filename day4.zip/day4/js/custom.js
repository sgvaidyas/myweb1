function showme()
{
    
    var menubar = document.getElementById("menu");

    if(menubar.style.display==="none"){
        
        menubar.style.display="block";
    }
    else{
        menubar.style.display="none"
    }
}